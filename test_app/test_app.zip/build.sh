#!/bin/sh

rm *.zip
zip -r test_app.zip .

