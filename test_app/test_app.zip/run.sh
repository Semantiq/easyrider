#!/bin/sh

echo "Hello test_app. My params: $*" > test_app.log

